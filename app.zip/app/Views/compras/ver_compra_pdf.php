<main>
    <div class="container-fluid">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="panel">
                <div class="embed-responsive embed-responsive-4by3 mt-20">
                    <iframe class="embed-responsive-item" src="<?=base_url()?>compras/generaCompraPdf/<?=$id_compra?>"></iframe>
                </div>
            </div>
        </div>
    </div>
</main>